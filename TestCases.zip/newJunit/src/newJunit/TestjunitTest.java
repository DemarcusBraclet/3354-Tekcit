
package newJunit;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestjunitTest {

	 
	/*
	@Test
	public void test() {
		Testjunit test = new Testjunit();
		int expected = 72;
		assertEquals("Here is the test for multiplication", expected, test.multiplyTwoNumbers(4, 8));
	} */
	

	
	@Test
	public void test1() {
		Testjunit test1 = new Testjunit();
		String expectedUsernameOrPasswordLengthIsZero = "Username or Password Length is 0";
		assertEquals("Username or Password Length is 0", expectedUsernameOrPasswordLengthIsZero, test1.registerNewUser("", "sm"));
	}
	
	@Test
	public void test2() {
		Testjunit test2 = new Testjunit();
		test2.registerNewUser("john", "rose");
		String expectedUsernameTake = "Username already taken";
		assertEquals("Username already taken", expectedUsernameTake, test2.registerNewUser("john", "leonard"));

	} 
	
	@Test
	public void test3() {
		Testjunit test3 = new Testjunit();
		String expectedUsernameOrPasswordLengthGreaterthanThree= "Username Or Password Length must be greater than 3";
		assertEquals("Username Or Password Length must be greater than 3", expectedUsernameOrPasswordLengthGreaterthanThree, test3.registerNewUser("john", "sm"));
	} 
	
	@Test
	public void test4() {
		Testjunit test4 = new Testjunit();
		String expectedValidUser =  "Registration Successful";
		assertEquals("Registration Successful\"", expectedValidUser, test4.registerNewUser("john", "smith"));

	} 
	
	
	
	

}
