package newJunit;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

public class Testjunit {
	HashMap<String, List<String>> newUsers = new HashMap<>();
	
	@Test
	public String registerNewUser(String username, String password) {
		
		if(username.length() == 0 || password.length() == 0) {
			return "Username or Password Length is 0";
		}
		
		if(newUsers.containsKey(username)) return "Username already taken";
		
		if(username.length() <= 3 || password.length() <= 3) {
			return "Username Or Password Length must be greater than 3";
		}
		
		
		
		
		List<String> newPassword = new ArrayList<>();
		newPassword.add(password);
		
		newUsers.put(username, newPassword);
	
		
		
		return "Registration Successful";
	}
	}
